export const environment = {
  production: true,
  serverUrl: 'https://qag82xnlel.execute-api.eu-west-1.amazonaws.com/api/v1/'
};
